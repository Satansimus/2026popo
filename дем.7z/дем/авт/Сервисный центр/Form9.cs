﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Сервисный_центр
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "автоDataSet2.Выроботанная_норма_заявок". При необходимости она может быть перемещена или удалена.
            this.выроботанная_норма_заявокTableAdapter.Fill(this.автоDataSet2.Выроботанная_норма_заявок);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            this.Hide();
            frm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.выроботаннаяНормаЗаявокBindingSource.RemoveCurrent();
            this.выроботанная_норма_заявокTableAdapter.Update(this.автоDataSet2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.выроботаннаяНормаЗаявокBindingSource.EndEdit();
            this.выроботанная_норма_заявокTableAdapter.Update(this.автоDataSet2);
        }
    }
}
