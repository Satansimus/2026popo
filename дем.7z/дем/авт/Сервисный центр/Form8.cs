﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Сервисный_центр
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "автоDataSet2.Вариантов_проводимых_работ". При необходимости она может быть перемещена или удалена.
            this.вариантов_проводимых_работTableAdapter.Fill(this.автоDataSet2.Вариантов_проводимых_работ);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.вариантовПроводимыхРаботBindingSource.RemoveCurrent();
            this.вариантов_проводимых_работTableAdapter.Update(this.автоDataSet2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.вариантовПроводимыхРаботBindingSource.EndEdit();
            this.вариантов_проводимых_работTableAdapter.Update(this.автоDataSet2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm = new Form3();
            this.Hide();
            frm.ShowDialog();
        }
    }
}
